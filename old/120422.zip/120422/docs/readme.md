Clone repository

git clone https://github.com/ekachernova/redi.git

Add modifications to git index

git add .

Commit changes

git commit -m "changes info"

Push to remote repository

git push 